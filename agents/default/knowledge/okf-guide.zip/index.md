---
type: index
title: Open Knowledge Format (OKF) Guide
description: Progressive disclosure catalog for Open Knowledge Format bundles and in-memory FTS5 search in Microharness.
tags: [okf, knowledge, fts5, microharness]
timestamp: 2026-10-27T11:30:00Z
---
# Open Knowledge Format (OKF) Guide

Welcome to the `okf-guide` knowledge bundle.

## Entry Points
- [Open Knowledge Format Specification](./concepts/open-knowledge-format.md) — Core anatomy of an OKF bundle (`type`, frontmatter, `index.md`, `log.md`, and Markdown links).
- [In-Memory SQLite FTS5 Search Engine](./concepts/fts5-search-engine.md) — How Microharness indexes `.zip` OKF bundles in memory with BM25 ranking and regex fallback without shell access.
- [Authoring OKF Knowledge Bundles](./howto/authoring-bundles.md) — Step-by-step guide to creating and packaging `.zip` knowledge bundles for `<agent>/knowledge/`.
- [Bundle Change Log](./log.md) — Chronological history of updates to this bundle.
