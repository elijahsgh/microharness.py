---
type: log
title: OKF Guide Change Log
description: Chronological update history for the okf-guide knowledge bundle.
tags: [okf, changelog]
timestamp: 2026-10-27T11:30:00Z
---
# Change Log

## 2026-10-27
- Initial release of `okf-guide.zip` with [Open Knowledge Format Specification](./concepts/open-knowledge-format.md), [In-Memory SQLite FTS5 Search Engine](./concepts/fts5-search-engine.md), and [Authoring OKF Knowledge Bundles](./howto/authoring-bundles.md).
