---
type: howto
title: Authoring OKF Knowledge Bundles
description: How to create, structure, and package a .zip Open Knowledge Format bundle for Microharness.
tags: [okf, howto, zip, packaging]
timestamp: 2026-10-27T11:30:00Z
---
# Authoring OKF Knowledge Bundles

To add a new knowledge bundle to an agent in Microharness:

1. Create a folder with a root [index.md](../index.md) (`type: index`), an optional [log.md](../log.md) (`type: log`), and topic `.md` files following the [Open Knowledge Format Specification](../concepts/open-knowledge-format.md).
2. Package the directory as a `.zip` file:
   ```bash
   zip -r my-bundle.zip index.md log.md concepts/ howto/
   ```
3. Drop `my-bundle.zip` into `<agent>/knowledge/my-bundle.zip`.
4. Microharness automatically indexes the `.zip` archive in memory on the next run (see [In-Memory SQLite FTS5 Search Engine](../concepts/fts5-search-engine.md)) and injects its catalog into the agent system prompt.
