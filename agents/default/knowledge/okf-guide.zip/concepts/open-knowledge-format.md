---
type: concept
title: Open Knowledge Format Specification
description: Google Open Knowledge Format (OKF) standard for portable, Markdown-based AI agent knowledge bundles.
resource: https://github.com/google/open-knowledge-format
tags: [okf, specification, markdown, frontmatter]
timestamp: 2026-10-27T11:30:00Z
---
# Open Knowledge Format Specification

The **Open Knowledge Format (OKF)** is a vendor-neutral specification introduced by Google for packaging domain context, datasets, metrics, and runbooks into portable Markdown bundles.

## Core Principles
1. **One Concept per Markdown File**: Each `.md` file represents a single concept, table, metric, or runbook. Its relative path within the bundle is its unique Concept ID.
2. **YAML Frontmatter**: Every file starts with YAML frontmatter containing a required `type` field (`concept`, `howto`, `table`, `metric`, `index`, `log`, etc.) and optional `title`, `description`, `resource`, `tags`, and `timestamp` fields.
3. **Reserved Progressive-Disclosure Files**:
   - `index.md`: Entry point catalog summarizing the bundle hierarchy ([see root index](../index.md)).
   - `log.md`: Chronological history of bundle updates ([see change log](../log.md)).
4. **Knowledge Graph via Relative Links**: Standard Markdown links connect related concepts—such as [In-Memory SQLite FTS5 Search Engine](./fts5-search-engine.md) and [Authoring OKF Knowledge Bundles](../howto/authoring-bundles.md)—allowing Microharness to compute both outgoing links and incoming backlinks automatically.
