---
type: concept
title: In-Memory SQLite FTS5 Search Engine
description: Fast, shell-free BM25 keyword and regex search over zipped Open Knowledge Format bundles.
tags: [fts5, bm25, sqlite, search, performance]
timestamp: 2026-10-27T11:30:00Z
---
# In-Memory SQLite FTS5 Search Engine

Instead of spawning `grep` or `ripgrep` subprocesses via a shell tool or extracting `.zip` archives to disk, Microharness indexes [Open Knowledge Format Specification](./open-knowledge-format.md) bundles directly in RAM:

- **Direct ZIP Ingestion (`zipfile`)**: Reads `.md` files directly from `<agent>/knowledge/*.zip` in milliseconds with zero disk extraction.
- **SQLite FTS5 + BM25 Ranking**: Uses `porter unicode61` stemming and weighted `bm25()` scoring (`title` 10x, `tags` 8x, `description` 6x, `type`/`path`/`resource` 4x, `body` 1x) with contextual `snippet()` highlights.
- **Regex & Literal Line Search**: Supports `mode="regex"` and `mode="literal"` for exact symbol or line-number matching when needed.
- **Automatic Backlinks**: Every document read via `read_knowledge` includes both `outgoing_links` and `backlinks` (incoming links from other documents in the bundle).
